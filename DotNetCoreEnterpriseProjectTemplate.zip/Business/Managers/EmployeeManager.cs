using $ext_projectname$.Core.Repository;
using $ext_projectname$.Core.Domain;

namespace $safeprojectname$.Managers
{
    public class EmployeeManager : BaseManager<Employee>
    {
        public EmployeeManager(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }
    }
}