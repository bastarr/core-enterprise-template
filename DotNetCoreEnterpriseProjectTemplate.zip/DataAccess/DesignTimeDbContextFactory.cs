using System.IO;
using $ext_projectname$.Core.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace $safeprojectname$
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<$ext_projectname$DbContext>
    {
        $ext_projectname$DbContext IDesignTimeDbContextFactory<$ext_projectname$DbContext>.CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddUserSecrets<$ext_projectname$DbContext>()
                .Build();
            var builder = new DbContextOptionsBuilder();
            builder.UseSqlServer(configuration["DbConnectionString"], b => b.MigrationsAssembly("$safeprojectname$"));
            return new $ext_projectname$DbContext(builder.Options);
        }
    }
}