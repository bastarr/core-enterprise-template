using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Models
{
    public class BusinessUnitModel
    {
        public long BusinessUnitId { get; set; }

        public string Name { get; set; }

        public string City { get; set; }
    }
}