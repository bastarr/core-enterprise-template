namespace $safeprojectname$
{
    public enum MockDataEntity
    {
        Employees,
        BusinessUnits      
    }
}